class Stadium < ActiveRecord::Base
end
