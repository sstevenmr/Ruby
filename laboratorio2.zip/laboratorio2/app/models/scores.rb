class Scores < ActiveRecord::Base
end
