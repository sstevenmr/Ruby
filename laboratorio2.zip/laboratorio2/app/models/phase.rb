class Phase < ActiveRecord::Base
end
