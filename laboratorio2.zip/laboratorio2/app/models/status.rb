class Status < ActiveRecord::Base
end
