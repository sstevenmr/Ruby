class Match < ActiveRecord::Base
end
