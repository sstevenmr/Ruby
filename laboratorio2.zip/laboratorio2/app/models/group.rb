class Group < ActiveRecord::Base
end
