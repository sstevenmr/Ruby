class Team < ActiveRecord::Base
end
