# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
Laboratorio2::Application.config.secret_key_base = 'e762e630db41fd45aa8c2240dd5327f9c7b6cf4dc6e9e48548bf1743ebf23d9eaf66f313532674a8b65f4f1401120d6b227b30e9d9b7a7c3eb0a3127fb7abb46'
